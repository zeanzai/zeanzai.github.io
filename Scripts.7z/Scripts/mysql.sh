

-- show GLOBAL VARIABLES;
-- show GLOBAL VARIABLES like "%activ%";

-- show GLOBAL VARIABLES like "%connection%";
show status like  'Threads%';
-- show variables like 'thread_cache_size';

-- set global thread_cache_size=64;



DROP INDEX inx_order_no on order_info ;

CREATE INDEX inx_order_no ON order_info(`order_no`);


DROP INDEX inx_user_id on order_info ; 

CREATE INDEX inx_user_id on order_info(`user_id`);
