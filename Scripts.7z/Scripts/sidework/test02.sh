#!/bin/bash

filename=/Users/shawnwang/Downloads/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS.mkv



# duration=`ffmpeg -i $filename  2>&1 | grep 'Duration' | \
# cut -d ' ' -f 4 | sed s/,// | sed 's@\*@@g' | \
# awk '{ split($1, A, ":");print A[1]*60*60*1000 + A[2]*60*1000 + A[3]*1000}'`

# echo "duration: $duration ms"


# outputfilename=/Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-part001.mkv
# ffmpeg -i $filename \
# -ss 0ms -to 60000ms \
# -c:a copy -c:v copy -keyint_min 2 -g 1 $outputfilename  -nostdin -y


# resultfilename=/Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-result001.mkv
# ffmpeg -i $outputfilename \
# -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/3,setdar=9/16,drawtext=fontfile=msyh.ttc:text='Part001':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='Friends':x=(w-text_w)/2:y=5*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
# -y $resultfilename




outputfilename2=/Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-part002.mkv
ffmpeg -i $filename -sameq -intra $outputfilename2





-----------
https://www.cnblogs.com/shuiche/p/13259579.html
精确时间裁剪视频#
全部帧都转换为关键帧, 将所有的帧的编码方式转为帧内编码
#旧版本

ffmpeg -i output.mp4 -sameq -intra keyoutput.mp4

 

#新版本

ffmpeg -i output.mp4 -strict -2  -qscale 0 -intra keyoutput.mp4


再开始裁剪视频
ffmpeg -ss 00:00:00 -t 00:00:30 -i test.mp4 -vcodec copy -acodec copy output.mp4


我的实验
ffmpeg -ss 00:01:00 -t 00:02:00 -i /Users/shawnwang/Downloads/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS.mkv \
 -strict -2 -qscale 0 -intra /Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-out001.mkv



ffmpeg -i /Users/shawnwang/Downloads/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS.mkv \
-ss 120000ms -to 240000ms \
-c:a copy -c:v copy -keyint_min 2 -g 1 /Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-out002.mkv  -nostdin -y

ffmpeg -ss 00:01:00 -to 00:02:00 -i /Users/shawnwang/Downloads/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS.mkv \
-c copy /Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-out005.mkv

------------    


ffmpeg -y -ss 00:00:10 -t 00:02:00 -i /Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-out.mkv \
-vcodec copy -acodec copy /Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-part005.mkv


ffmpeg -i input.mkv -map 0:s:0 out.ass

这将下载第一个字幕轨。如果有几个，使用0:s:1下载第二个，0:s:2下载第三个，等等。

字幕格式是srt或者ass修改后缀名就可以了；

法二、视频添加提取字幕：

ffmpeg -i F:\472ca95769ddf65f288ed6da2602ef89.mp4 -i F:\lc.srt -map 0:0 -map 0:1 -map 1 -c:a copy -c:v copy -c:s copy F:\video.mkv

ffmpeg -i F:\video.mkv -vn -an -codec:s:0 srt F:\subtitle.srt



ffmpeg -i /Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-part001.mkv \
 -vf "split[a][b];[a]pad=iw:ih*2[a];[b]vflip[b];[a][b]overlay=0:h" /Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-part003.mkv



ffmpeg -y -i /Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-part001.mkv \
 -codec:v libx264 -codec:a mp3 -map 0 -f ssegment -segment_format mpegts -segment_list e:\video\m\playlist.m3u8 -segment_time 10 e:\video\m\ts-%03d.ts




 ffprobe -i /Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-part001.mkv \
  -v quiet -select_streams v -show_entries frame=pkt_pts_time,pict_type



ffmpeg -i course_16335_video_normalWatermark_864w360h.mp4 -vf "delogo=x=714:y=28:w=130:h=50" -c:a copy course_16335_video_normalWatermark_864w360h_removedWatermarked.mp4



ffmpeg -i 1.flv -vcodec copy -acodec copy 001.mp4

ffmpeg -ss 60000ms -to 70000ms -i 001.mp4 -c copy -y 001_out.mp4

ffplay -f lavfi -i "movie=001_out.mp4,delogo=x=265:y=15:w=40:h=20"

ffmpeg -i 001_out.mp4 \
    -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/3,setdar=9/16,drawtext=fontfile=/System/Library/Fonts/PingFang.ttc:text='豫剧刘忠河打金枝':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=/System/Library/Fonts/PingFang.ttc:text='选段一':x=(w-text_w)/2:y=5*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
    -y 001_out_out.mp4

ffmpeg -i 001_out.mp4 -vf "delogo=x=265:y=15:w=40:h=20" -c:a copy -y 001_out_out.mp4

ffmpeg -i 001_out_out.mp4 \
    -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/3,setdar=9/16,drawtext=fontfile=/System/Library/Fonts/PingFang.ttc:text='豫剧刘忠河打金枝':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=/System/Library/Fonts/PingFang.ttc:text='选段一':x=(w-text_w)/2:y=5*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
    -y 001_out_out_out.mp4

# 1. 转mp4



# ## 获取封面图

# 
ffmpeg -i 001.mp4 -ss 00:01:22 -frames:v 1 out.png


ffmpeg -i out.png -vf scale=1920:1080 output_001.png


ffmpeg -i 002.mp4 -ss 00:01:22 -frames:v 1 -vf scale=1920:1080 002.png
ffmpeg -i 003.mp4 -ss 00:01:22 -frames:v 1 -vf scale=1920:1080 003.png