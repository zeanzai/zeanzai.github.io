#!/bin/bash
# for i in *.avi;
#   do name=`echo "$i" | cut -d'.' -f1`
#   echo "$name"
#   ffmpeg -i "$i" "${name}.mov"
# done

# ffmpeg -i 00开篇词：照着做，你也能成为架构师！.mp3 -metadata title="00开篇词：照着做，你也能成为架构师！" 00开篇词：照着做，你也能成为架构师！.mp3

# export PATH=/Users/shawnwang/Develop/ffmpeg4.4.1/bin/:$PATH

for i in *.mp3; 
    do ffmpeg -i "$i" -metadata title="$i" ./temp/"$i"  ; 
done


