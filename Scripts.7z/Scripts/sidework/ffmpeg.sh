
# 把视频2倍速播放后，转换成mp4格式输出
ffmpeg -i 0001.mov -filter_complex "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2.0[a]" -map "[v]" -map "[a]" 0001.mp4


https://blog.csdn.net/ternence_hsu/article/details/90578565
ffmpeg -ss 0 -t 30  -f lavfi -i color=c=0x58878b:s=1280x720:r=25 -vcodec libx264 -r:v 25 test1.mp4
0x0000ff 为配置当前视频的颜色，这里直接配置对应的RGB值
-t 配置输出视频时长
-r 帧率
-s 分辨率


ffmpeg -i test1.mp4 -vf drawtext=fontcolor=black:fontsize=50:text='Hello World':x=0:y=100 -y out.mp4


-- 生成纯色的、带文字的、30s视频
ffmpeg -ss 0 -t 30  -f lavfi -i color=c=0x58878b:s=1280x720:r=25 -vcodec libx264 -r:v 25 \
-vf drawtext=fontcolor=0x5887ff:fontsize=90:text='Hello World':x=100:y=100 -y test2.mp4





-- 提取音频
ffmpeg -i /Users/shawnwang/Downloads/有声书/0002.mp4 -f mp3 -vn /Users/shawnwang/Downloads/有声书/001.mp3

-- 

ffmpeg -i "$i" -map 0 -c copy -metadata album="" -metadata artist="" -metadata title="" $outputfilename -y


ffmpeg -i FC2-PPV-3259498.mp4 -c:a copy -c:v copy  -y FC2-PPV-3259498-01.mp4

ffmpeg -i 03.mp3 -ss 0 -t 10 -y 02.mp3
