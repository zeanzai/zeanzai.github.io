#!/bin/bash

# 源视频文件绝对路径
basePath=/Users/shawnwang/Downloads/temp/Gotham/
seasonPath=S01

eposideName=E01
videoNameWithoutExt=.mp4

topText="Gotham-"$seasonPath$eposideName
bottomText='follow for more'

videoFilePath=$basePath$seasonPath"/"$eposideName$videoNameWithoutExt
sliceVideoOutFolderPath=$basePath$seasonPath"/"$eposideName"/slices"
editedVideoOutFolderPath=$basePath$seasonPath"/"$eposideName"/edited"
mkdir -p $sliceVideoOutFolderPath
mkdir -p $editedVideoOutFolderPath


# 每片视频长度： 1min
eachSliceLength=60000

videoLength=$(ffmpeg -i $videoFilePath  2>&1 | grep 'Duration' | \
cut -d ' ' -f 4 | sed s/,// | sed 's@\*@@g' | \
awk '{ split($1, A, ":");print A[1]*60*60*1000 + A[2]*60*1000 + A[3]*1000}')

echo "video length is: $videoLength ms"

startTime=0
endTime=0
i=0



while [ $endTime -le $videoLength ]; do
    i=$[$i+1]
	endTime=$[$startTime+$eachSliceLength]
    num=`echo $i | awk '{printf("%03d",$0)}'`;

    sliceName=$sliceVideoOutFolderPath"/"$num$videoNameWithoutExt
    editeName=$editedVideoOutFolderPath"/"$num$videoNameWithoutExt
    topValue=$topText" Part "$num
    echo "========== start: $topValue, startTime: $startTime ms, endTime: $endTime ms, slice: $sliceName, edite: $editeName"

    # 分片
    ffmpeg -y -i $videoFilePath -ss $startTime"ms" -to $endTime"ms" -c:a copy -vcodec libx264 -keyint_min 2 -g 1 $sliceName -hide_banner

    # 输出
    ffmpeg -i $sliceName \
    -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/3,setdar=9/16,drawtext=fontfile=msyh.ttc:text='$topValue':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='$bottomText':x=(w-text_w)/2:y=5*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
    -y $editeName

    
    startTime=$[endTime]
done

# ffmpeg -i $videoFilePath  2>&1 | grep 'Duration' | \
# cut -d ' ' -f 4 | sed s/,// | sed 's@\*@@g' | \
# awk '{ split($1, A, ":");print A[1]*60*60*1000 + A[2]*60*1000 + A[3]*1000}'


# ffmpeg -i /Users/shawnwang/Downloads/temp/Gotham/S01/E01.mp4 \
# -ss 2760000ms -to 2770000ms \
# -c:a copy -c:v copy -keyint_min 2 -g 1 /Users/shawnwang/Downloads/temp/Gotham/S01/E01_out/048.mp4 -hide_banner  -nostdin -y

# ffmpeg -i /Users/shawnwang/Downloads/temp/Gotham/S01/E01_out/048.mp4 \
# -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/3,setdar=9/16,drawtext=fontfile=msyh.ttc:text='Gotham-S01E01':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='followformore':x=(w-text_w)/2:y=5*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
# -y /Users/shawnwang/Downloads/temp/Gotham/S01/E01_out/048_003.mp4


