#!/bin/bash


# 从文件中读取要截取的音视频片段的时间间隔，然后进行切割并重新渲染；
# 只截取好听的部分片段；

originFolder=/d/Backup/Study2/temp
destinationFolder=/e/Backup/Study2/



cd $originFolder

k=0


for i in *.MP4;
  do name=`echo "$i" | cut -d'.' -f1`
  echo "$name"

  k=$[$k+1]
  num=`echo $k | awk '{printf("%03d",$0)}'`;
  ffmpeg -i "$i" -c:a copy -c:v copy  -y $destinationFolder"$num.mp4" 

done

