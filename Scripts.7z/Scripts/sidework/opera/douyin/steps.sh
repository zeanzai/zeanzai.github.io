#!/bin/bash


originFolder=/d/Backup/Study2/temp
destinationFolder=/e/Backup/Study2/



cd $originFolder

k=0


for i in *.MP4;
  do name=`echo "$i" | cut -d'.' -f1`
  echo "$name"

  k=$[$k+1]
  num=`echo $k | awk '{printf("%03d",$0)}'`;
  ffmpeg -i "$i" -c:a copy -c:v copy  -y $destinationFolder"$num.mp4" 

done

