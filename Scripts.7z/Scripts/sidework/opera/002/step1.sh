#!/bin/bash

###########################

###########################

folderPath=/Users/shawnwang/Documents/BaiduSyncDisk/Sidework/Opera/002
fileNameWithoutExt=003
fileExt=.flv
rtfileExt=.mp4

filePath=$folderPath"/"$fileNameWithoutExt$fileExt

fileOutPath=$folderPath"/temp"$fileNameWithoutExt$rtfileExt

fileResultPath=$folderPath"/"$fileNameWithoutExt$rtfileExt

# 去掉 80s 的报幕 ， 并把格式调整为 mp4
ffmpeg -ss 79000ms -i $filePath -c copy -y $fileOutPath

# 去除水印
# 关于去水印 https://crifan.github.io/media_process_ffmpeg/website/video_process/watermark/remove_watermark.html
ffmpeg -i $fileOutPath -vf "delogo=x=265:y=15:w=40:h=20" -c:a copy -y $fileResultPath


