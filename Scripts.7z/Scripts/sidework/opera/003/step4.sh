#!/bin/bash

# 把修改后的mp4，截取题记和据尾，然后把视频合成一段
ffmpeg -f concat -safe 0 -i "D:\Source\Local\Scripts\sidework\opera\003\video.txt" -acodec copy -vcodec copy -y "D:\DocHub\Moonlight\001-豫剧刘忠河打金枝\04-live\003.mp4" -hide_banner  



ffmpeg -i 043.mp4 -vcodec copy -acodec copy -movflags faststart 044.mp4.

