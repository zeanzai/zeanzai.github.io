#!/bin/bash

###########################
## 关于添加字体乱码的问题： https://wxnacy.com/2019/04/08/ffmpeg-drawtext/
###########################

folderPath=/Users/shawnwang/Documents/BaiduSyncDisk/Sidework/Opera
fileNameWithoutExt=temp002
fileExt=.mp4

filePath=$folderPath"/"$fileNameWithoutExt$fileExt

slicePath=$folderPath"/"$fileNameWithoutExt"/slice/"

resultPath=$folderPath"/"$fileNameWithoutExt"/result/"

mkdir -p $slicePath $resultPath

duration=`ffmpeg -i $filePath  2>&1 | grep 'Duration' | \
cut -d ' ' -f 4 | sed s/,// | sed 's@\*@@g' | \
awk '{ split($1, A, ":");print A[1]*60*60*1000 + A[2]*60*1000 + A[3]*1000}'`
echo "duration: $duration ms"

eachSliceLength=60000 # 60s

startTime=0
endTime=0
i=67

while [ $endTime -le $duration ]; 
do
    i=$[$i+1]
	endTime=$[$startTime+$eachSliceLength]
    num=`echo $i | awk '{printf("%03d",$0)}'`;

    sliceName=$slicePath$num$fileExt
    editeName=$resultPath$num$fileExt
    
    echo
    echo
    echo "========== startTime: $startTime ms, endTime: $endTime ms, slice: $sliceName"

    # 分片
    ffmpeg -ss $startTime"ms" -to $endTime"ms" -i $filePath \
    -c copy -y $sliceName

    # 抖音格式
    ffmpeg -i $sliceName \
    -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/3,setdar=9/16,drawtext=fontfile=/System/Library/Fonts/PingFang.ttc:text='豫剧刘忠河打金枝':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=/System/Library/Fonts/PingFang.ttc:text='选段$num':x=(w-text_w)/2:y=5*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
    -y $editeName

    startTime=$[endTime]
done


