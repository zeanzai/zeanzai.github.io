#!/bin/bash

folderPath=/Users/shawnwang/Documents/BaiduSyncDisk/Sidework/Opera/003-刘墉下南京
originFolder=00-origin

originFolderPath=$folderPath"/"$originFolder
mp4Floder=$folderPath"/01-mp4"

mkdir -p $mp4Floder

num=0

cd $originFolderPath
for i in *.avi; do 
    originVideo=$originFolderPath"/"$i 
    echo $originVideo

    num=$[$num+1]
    videoNum=`echo $num | awk '{printf("%03d",$0)}'`;
    destVideo=$mp4Floder"/"$videoNum".mp4"
    echo $destVideo

    # 把格式调整为 mp4
    ffmpeg -i "$originVideo" -c:a copy -c:v copy -y $destVideo
done


# ffmpeg -i "/Users/shawnwang/Documents/BaiduSyncDisk/Sidework/Opera/003-刘墉下南京/00-origin/豫剧：刘墉下南京05 WwW.戏迷.CN.avi" \
# -c copy -y /Users/shawnwang/Documents/BaiduSyncDisk/Sidework/Opera/003-刘墉下南京/01-mp4/005.mp4

# fileNameWithoutExt=002
# fileExt=.flv
# rtfileExt=.mp4

# filePath=$folderPath"/"$fileNameWithoutExt$fileExt

# fileOutPath=$folderPath"/temp"$fileNameWithoutExt$rtfileExt

# fileResultPath=$folderPath"/"$fileNameWithoutExt$rtfileExt

# # 把格式调整为 mp4
# ffmpeg -i $filePath -c copy -y $fileOutPath


## 步骤
# 1. 改格式： 调整格式为mp4
# 2. 获取合集封面： 截取第一集中某一帧作为合集封面
# 3. 切片： 遍历所有分集，并把每一集都切片，切片顺序连续
# 4. 重新渲染： 把每一个切片重新渲染成抖音标准格式
# 5. 合并分集： 把所有分集合并成一集，用于后续的直播

