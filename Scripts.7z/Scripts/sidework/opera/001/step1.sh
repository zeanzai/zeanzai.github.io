#!/bin/bash

folderPath=/Users/shawnwang/Documents/BaiduSyncDisk/Sidework/Opera
fileNameWithoutExt=002
fileExt=.flv
rtfileExt=.mp4

filePath=$folderPath"/"$fileNameWithoutExt$fileExt

fileOutPath=$folderPath"/temp"$fileNameWithoutExt$rtfileExt

fileResultPath=$folderPath"/"$fileNameWithoutExt$rtfileExt

# 把格式调整为 mp4
ffmpeg -i $filePath -c copy -y $fileOutPath

