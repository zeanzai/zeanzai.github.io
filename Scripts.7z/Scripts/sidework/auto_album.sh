#!/bin/bash


filename=1.mp4

eachLength=10

startTime=0
endTime=0
length=300
i=0



while [ $endTime -le $length ]; do
	i=$[$i+1]
	endTime=$[$startTime+$eachLength]
	ffmpeg -i $filename  -ss $startTime -to $endTime -acodec copy -vcodec copy temp/$i.mp4
	startTime=$[endTime]
done






#!/bin/bash

## 文件设置
fileName=04
fileSep="."
fileExt=mp4
fileNameWithExt=$fileName$fileSep$fileExt

folderName=$fileName"_cuted"
mkdir -p $folderName/slices $folderName/output 


## 切片设置
eachSliceLength=60
startTime=0
endTime=0
i=0

vedioLength=`ffmpeg -i $fileNameWithExt  2>&1 | grep 'Duration' | cut -d ' ' -f 4 | sed s/,// | sed 's@\..*@@g' | awk '{ split($1, A, ":"); split(A[3], B, "."); print 3600*A[1] + 60*A[2] + B[1] }'`
echo $vedioLength

while [ $endTime -le $vedioLength ]; do
	i=$[$i+1]
	endTime=$[$startTime+$eachSliceLength+1]
  # num=$i + %2d
  echo "$i, startTime: $startTime, endTime: $endTime"
	ffmpeg -ss $startTime -to $endTime -accurate_seek -i $fileNameWithExt -c:v libx264 -c:a aac -strict experimental -b:a 98k ./$folderName/slices/$fileName"_"$i.mp4 -y
  startTime=$[endTime]
done




#!/bin/bash

cd ../slices/

headtextvalue="S06E05"

midtextvalue="《Gotham》"
botomtextvalue="followformore"

for i in *.mp4;
  do name=`echo "$i" | cut -d'.' -f1`
  echo $i
  # ffmpeg01="ffmpeg -i ../slices/$i -vf "
  # vfparam01="\"split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,"
  # headtext="drawtext=fontfile=msyh.ttc:text='$headtextvalue':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,"
  # midtext="drawtext=fontfile=msyh.ttc:text='$midtextvalue':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,"
  # botomtext="drawtext=fontfile=msyh.ttc:text='$botomtextvalue':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow\""
  # ffmpeg02=" -y ../edited/$name.mp4"
  # commond=$ffmpeg01$vfparam01$headtext$midtext$botomtext$ffmpeg02
  # # echo $commond

  # `$commond`

  ffmpeg -i ../slices/$i \
  -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='$headtextvalue':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='$midtextvalue':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='$botomtextvalue':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
  -y ../edited/$name.mp4

  done



# ffmpeg -i ../slices/06_5.mp4 -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='S06 E05':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='《Gotham》':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='follow for more':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" -y ../slices/06_5.mp4


# ffmpeg -re -i 1.mp4 -c copy -f segment -segment_format mp4 test_outpout-%d.mp4


# ffmpeg -i temp/1.mp4 -aspect 9:16 temp/1-out.mp4

ffmpeg -i temp/2.mp4 -vf "scale=iw/2:ih/2" -aspect 9:16 temp/2-out.mp4 -y


ffmpeg -i Gotham.s05e04.BD1080p.mp4  -ss 01:00 -to 02:00 -acodec copy -vcodec copy test/01.mp4

ffmpeg -i test/01.mp4 \
-vf "split[fg0][bg0];" \
"[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];" \
"[fg0]scale=720:(720*ih/iw)[fg1];" \
"[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='" \
"01 PART07" \
"':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='" \
"《Big Bang》" \
"':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='" \ 
"~ 点关注不迷路 ~" \ 
"':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
-y test/01_002.mp4


ffmpeg -i test/01.mp4 -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='01 PART07':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='《Big Bang》':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='~ 点关注不迷路 ~':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" -y test/01_002.mp4

ffmpeg -i test/01.mp4 \
-vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='01 PART07':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='《Big Bang》':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='~ 点关注不迷路 ~':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
-y test/01_002.mp4


ffmpeg -i test/01.mp4 \
-vf "split[a][b];[a]scale=1080:1920,boxblur=10:5[1];[b]scale=1080:ih*1080/iw[2];[1][2]overlay=0:(H-h)/2" \
-c:v libx264 -crf 18 -preset veryfast -aspect 9:16  -f mp4 test/01_001.mp4 -y


1. 添加黑色滤镜
2. 把视频放到滤镜上


#!/bin/bash

## 切片

## 文件设置
fileName=06
fileSep="."
fileExt=mp4
fileNameWithExt=$fileName$fileSep$fileExt


outputFilePath=slices/

## 切片设置
eachSliceLength=60
startTime=0
endTime=0
i=0

vedioLength=`ffmpeg -i ../original/$fileNameWithExt  2>&1 | grep 'Duration' | cut -d ' ' -f 4 | sed s/,// | sed 's@\..*@@g' | awk '{ split($1, A, ":"); split(A[3], B, "."); print 3600*A[1] + 60*A[2] + B[1] }'`
echo $vedioLength

# 拼接命令
# headtextvalue="01 PART07"
# midtextvalue="《Gotham》"
# botomtextvalue="follow for more"

while [ $endTime -le $vedioLength ]; do
	i=$[$i+1]
	endTime=$[$startTime+$eachSliceLength+1]
  # num=$i + %2d
  echo "$i, startTime: $startTime, endTime: $endTime"
	ffmpeg -ss $startTime -to $endTime -accurate_seek -i ../original/$fileNameWithExt -c:v libx264 -c:a aac -strict experimental -b:a 98k ../slices/$fileName"_"$i.mp4 -y
  startTime=$[endTime]
done




#!/bin/bash

cd ../slices/

headtextvalue="S06E05"

midtextvalue="《Gotham》"
botomtextvalue="followformore"

for i in *.mp4;
  do name=`echo "$i" | cut -d'.' -f1`
  echo $i
  # ffmpeg01="ffmpeg -i ../slices/$i -vf "
  # vfparam01="\"split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,"
  # headtext="drawtext=fontfile=msyh.ttc:text='$headtextvalue':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,"
  # midtext="drawtext=fontfile=msyh.ttc:text='$midtextvalue':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,"
  # botomtext="drawtext=fontfile=msyh.ttc:text='$botomtextvalue':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow\""
  # ffmpeg02=" -y ../edited/$name.mp4"
  # commond=$ffmpeg01$vfparam01$headtext$midtext$botomtext$ffmpeg02
  # # echo $commond

  # `$commond`

  ffmpeg -i ../slices/$i \
  -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='$headtextvalue':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='$midtextvalue':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='$botomtextvalue':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
  -y ../edited/$name.mp4

  done



# ffmpeg -i ../slices/06_5.mp4 -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='S06 E05':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='《Gotham》':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='follow for more':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" -y ../slices/06_5.mp4





#!/bin/bash

## 文件设置
fileName=04
## 切片设置
eachSliceLength=300
headtextvalue="S04E01"
midtextvalue="《Gotham》"
botomtextvalue="followformore"

fileSep="."
fileExt=mp4
fileNameWithExt=$fileName$fileSep$fileExt
folderName=$fileName"_cuted"
mkdir -p $folderName/slices $folderName/output 
startTime=0
endTime=0
i=0

vedioLength=`ffmpeg -i $fileNameWithExt  2>&1 | grep 'Duration' | cut -d ' ' -f 4 | sed s/,// | sed 's@\..*@@g' | awk '{ split($1, A, ":"); split(A[3], B, "."); print 3600*A[1] + 60*A[2] + B[1] }'`
echo $vedioLength

while [ $endTime -le $vedioLength ]; do
	i=$[$i+1]
	endTime=$[$startTime+$eachSliceLength+1]
  echo "========== start: $i, startTime: $startTime, endTime: $endTime"
	
  # ffmpeg -i $fileNameWithExt -ss $startTime -to $endTime -acodec copy -vcodec copy ./$folderName/slices/$fileName"_"$i.mp4 -y
  # ffmpeg -ss $startTime -i $fileNameWithExt -to $endTime -c copy ./$folderName/slices/$fileName"_"$i.mp4 -y
  ffmpeg -ss $startTime -to $endTime -accurate_seek -i $fileNameWithExt -c:v libx264 -c:a aac -strict experimental -b:a 98k ./$folderName/slices/$fileName"_"$i.mp4 -y
  
  # ffmpeg -i ./$folderName/slices/$fileName"_"$i.mp4 \
  # -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='$headtextvalue':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='$midtextvalue':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='$botomtextvalue':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
  # -y ./$folderName/output/$fileName"_"$i.mp4

  startTime=$[endTime]
done



ffmpeg -i $filename  -ss $startTime -to $endTime -acodec copy -vcodec copy temp/$i.mp4

ffmpeg -i test/01.mp4 \
-vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='01 PART07':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='《Big Bang》':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='~ 点关注不迷路 ~':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
-y test/01_002.mp4


fontfile=PingFang.ttc:




## 拼接后命令
ffmpeg -i 04.mp4 -ss 00:03:00 -to 00:05:00  \
-vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=text='01 PART07':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=text='《Big Bang》':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=text='~ 点关注不迷路 ~':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow"  04_test.mp4

ffmpeg -y \
-i /Users/shawnwang/Downloads/temp/Gotham/S01/E01.mp4 -ss 420000ms -to 480000ms \
-c:a copy -vcodec libx264 -keyint_min 2 \
-g 1 \
/Users/shawnwang/Downloads/temp/Gotham/S01/E01_out02.mp4 -hide_banner



#!/bin/bash


## TODO
# 1. 获取视频总时长，以s为单位；
# 2. 构造单个切片文件的处理命令
# 3. 循环处理


## 文件设置
fileName=8
fileSep="."
fileExt=mp4
fileNameWithExt=$fileName$fileSep$fileExt
outputFilePath=out1/

## 切片设置
eachSliceLength=60
startTime=0
endTime=0
i=0

## 


## 0. 获取视频时长
# ffmpeg -i 04.mp4 2>&1 | grep 'Duration' | cut -d ' ' -f 4 | sed s/,//
# ffmpeg -i 04.mp4 2>&1 | grep "Duration" | cut -d ' ' -f 4 | sed s/,// | sed 's@\..*@@g' | awk '{ split($1, A, ":"); split(A[3], B, "."); print 3600*A[1] + 60*A[2] + B[1] }'

vedioLength=`ffmpeg -i $fileNameWithExt  2>&1 | grep 'Duration' | cut -d ' ' -f 4 | sed s/,// | sed 's@\..*@@g' | awk '{ split($1, A, ":"); split(A[3], B, "."); print 3600*A[1] + 60*A[2] + B[1] }'`
echo $vedioLength

# 拼接命令
# headtextvalue="01 PART07"
midtextvalue="《Gotham》"
botomtextvalue="follow for more"

while [ $endTime -le $vedioLength ]; do
	i=$[$i+1]
	endTime=$[$startTime+$eachSliceLength]
	# ffmpeg -i $filename  -ss $startTime -to $endTime -acodec copy -vcodec copy temp/$i.mp4
	
  # echo "$i, startTime: $startTime, endTime: $endTime"
  headtextvalue=$fileName$i 
  ffmpeg01="ffmpeg -i $fileNameWithExt -ss $startTime -to $endTime -vf "
  vfparam01="\"split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,"
  headtext="drawtext=fontfile=msyh.ttc:text='$headtextvalue':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,"
  midtext="drawtext=fontfile=msyh.ttc:text='$midtextvalue':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,"
  botomtext="drawtext=fontfile=msyh.ttc:text='$botomtextvalue':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow\""
  ffmpeg02=" -y $outputFilePath$headtextvalue$fileSep$fileExt"
  commond=$ffmpeg01$vfparam01$headtext$midtext$botomtext$ffmpeg02
  echo $commond
  # `$commond`
  startTime=$[endTime]
  

done




### TODO

1. 第一个步骤是先切，把长视频切割成等长的小视频；
ffmpeg -i $filename -ss $startTime -to $endTime -acodec copy -vcodec copy temp/$i.mp4




2. 第二步是进行编辑；

ffmpeg -i test/01.mp4 \
-vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/2,setdar=9/16,drawtext=fontfile=msyh.ttc:text='01 PART07':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='《Big Bang》':x=(w-text_w)/2:y=(h-text_h)/4:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='~ 点关注不迷路 ~':x=(w-text_w)/2:y=6*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
-y test/01_002.mp4


###########
# ffprobe -v quiet -print_format json -show_format -show_streams test/01.mp4
