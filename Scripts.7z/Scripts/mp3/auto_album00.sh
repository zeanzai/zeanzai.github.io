#!/bin/bash


filename=/Users/shawnwang/Downloads/冯唐讲资治通鉴
album=冯唐讲资治通鉴


cd $filename
mkdir cuted
mkdir cuted01

for i in *.mp3;
  do name=`echo "$i" | cut -d'.' -f1`
  echo "$name"

  ## 音频元数据中有各种设置的广告信息，最主要的原因是： 
  ##    一个多媒体文件包含了多个stream，其中例如音频封面等元数据是属于stream1的，使用ffmpeg查看，可知这个stream是一个video的格式，
  ## 所以只把mp3中的音频部分复制拷贝出来即可。
  ## -vn 表示视频不输出，Video Not
  ffmpeg -i "$i" -f mp3 -vn ./cuted/"$i" -y

  ## 之后需要把音频文件导入到一些播放器软件中，所以需要设置一些信息，以便于把这些音频文件归类。
  ## 大多数播放器软件都可以使用 album 或者 artist 进行归类。
  ## -metadata xxx ，表示修改元数据中的 xxx 项
  ffmpeg -i ./cuted/"$i" -map 0 -c copy -metadata album="$album" -metadata title="$name" ./cuted01/"$i" -y

done




