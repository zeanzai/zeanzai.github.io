#!/bin/bash

basefolder=/Users/shawnwang/Downloads/mp3/

foldername=面试现场
album=面试现场
artist=$album

outputfolder=$basefolder"cuted/"$foldername
mkdir -p $outputfolder

cd $basefolder$foldername



for i in *.mp3;
do 
  name=`echo "$i" | cut -d'.' -f1`
  outputfilename=$outputfolder"/"$i
  echo $outputfilename

  ffmpeg -i "$i" -map 0 -c copy -metadata album="$album" -metadata artist="$artist" -metadata title="$name" $outputfilename -y

done






ffmpeg -y -i /Users/shawnwang/Downloads/mp3/music/黄灿-康定情歌01.mp3 \
 -map 0 -c copy \
 -metadata album="zeanzai" \
 -metadata artist="黄灿" \
 -metadata title="康定情歌" \
 /Users/shawnwang/Downloads/mp3/music/out/康定情歌.mp3


ffmpeg -i /Users/shawnwang/Downloads/mp3/music/out/黄玫瑰.mp3 \
-ss 00:00:00 -to 4:30 \
/Users/shawnwang/Downloads/mp3/music/out/黄玫瑰02.mp3


ffmpeg -i /Users/shawnwang/Downloads/mp3/music/黄灿-康定情歌.mp4  \
/Users/shawnwang/Downloads/mp3/music/黄灿-康定情歌01.mp3


