#!/bin/bash

# 删除某个文件夹内所有的 

folder=/Volumes/Shawn/geektimes/01


function ergodic(){
    for file in `ls $1`
    do
        if [ -d $1"/"$file ]
        then
            ergodic $1"/"$file
        else
            local path=$1"/"$file 
            local name=$file
    #   local size=`du --max-depth=1 $path|awk '{print $1}'` 
            # echo $path 
            # echo $path
            local name=`echo "$path" | cut -d'.' -f2`
            # echo $name
            if [ "$name" == "html" ] 
            then 
                # filepath=`echo $path | awk -F "$folder" '{print $2}'`
                echo $path
                rm -rf $path
                # echo $folder$filepath
            fi
    fi
  done
}
IFS=$'\n' #这个必须要，否则会在文件名中有空格时出错

ergodic $folder






# find ./ -name “*.txt” | xargs -I{} mv {} 目标目录


## 获取文件目录
# function ergodic(){
#     for file in `ls $1`
#     do
#         if [ -d $1"/"$file ]
#         then
#             ergodic $1"/"$file
#         else
#             local path=$1"/"$file 
#     #   local name=$file      
#     #   local size=`du -h -1 $path|awk '{print $1}'`
#             echo $path
#             # local name=`echo "$path" | cut -d'.' -f2`
#             # # echo $name
#             # if [ "$name" == "mp3" ] 
#             # then 
#             #     filepath=`echo $path | awk -F "$folder" '{print $2}'`
#             #     # echo $filepath
#             #     echo $folder$filepath
#             # fi
#         fi
#     done
# }
# IFS=$'\n' #这个必须要，否则会在文件名中有空格时出错

# ergodic $folder

# function listdir(){
#     for foldername in `ls $folder`
#     do 
#         # echo $folder$foldername
#         # mkdir -p 
#         # echo $folder"/mp3/"$foldername
#         ergodic $folder"/"$foldername
#     done 
# }


# listdir

