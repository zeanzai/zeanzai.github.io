#!/bin/bash


#########
# 提取所有的mp3，并删除mp3的元数据
#########


folderpath=/Users/shawnwang/Downloads/geektime/
foldername=177-恋爱必修课

folder=$folderpath$foldername

despath=$folderpath"/mp3/"$foldername

mkdir $despath
function ergodic(){
    for file in `ls $1`
    do
        if [ -d $1"/"$file ]
        then
            ergodic $1"/"$file
        else
            local path=$1"/"$file 
            local filename=`echo "$file" | cut -d'.' -f1`
            local name=`echo "$path" | cut -d'.' -f2`
            if [ "$name" == "mp3" ] 
            then 
                # -c:a copy ： 拷贝出音频数据， -vn ： 不输出视频，封面就是视频， -map_metadata -1 ： 删除所有元数据
                ffmpeg -i $path -c:a copy -vn -map_metadata -1  -y $despath"/"$file
                
            elif [ "$name" == "m4a" ] ; then 
                # echo $filename
                # -c:a copy ： 拷贝出音频数据， -vn ： 不输出视频，封面就是视频， -map_metadata -1 ： 删除所有元数据
                ffmpeg -i $path -acodec mp3 -vn -map_metadata -1  -y $despath"/"$filename".mp3"
                
            fi
    fi
  done
}
IFS=$'\n' #这个必须要，否则会在文件名中有空格时出错

ergodic $folder


