# 设置免密登录
ssh-copy-id -i ~/.ssh/id_ed25519.pub root@192.168.1.150

