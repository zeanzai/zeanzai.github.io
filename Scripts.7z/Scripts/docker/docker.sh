docker空间清理： 
https://blog.csdn.net/longailk/article/details/122728982



docker ps -a
docker images
docker rm mysql-master
docker system df
docker container prune：删除无用的容器。




