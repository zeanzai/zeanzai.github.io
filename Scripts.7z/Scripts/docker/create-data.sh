参考： https://www.jianshu.com/p/cf5d381ef637




#建测试表
drop table if exists t;
CREATE TABLE t (
                id int NOT NULL AUTO_INCREMENT PRIMARY KEY comment '自增主键', 
                dept tinyint not null comment '部门id',
                age tinyint not null comment '年龄',
                name varchar(30) comment '用户名称',
                create_time datetime not null comment '注册时间', 
                last_login_time datetime comment '最后登录时间'
               ) comment '测试表';
 
#手工插入第一条测试数据，后面数据会根据这条数据作为基础生成
insert into t values(1,1, 25, 'user_1', '2018-01-01 00:00:00', '2018-03-01 12:00:00');
#初始化序列变量
set @i=1;
#==================此处拷贝反复执行，直接符合预想的数据量===================
#执行20次即2的20次方=1048576 条记录
#执行23次即2的23次方=8388608 条记录
#执行24次即2的24次方=16777216 条记录
#......
insert into t(dept, age, name, create_time, last_login_time) 
select left(rand()*10,1) as dept,               #随机生成1~10的整数
       FLOOR(20+RAND() *(50 - 20 + 1)) as age,  #随机生成20~50的整数
        concat('user_',@i:=@i+1),               #按序列生成不同的name
        date_add(create_time,interval +@i*cast(rand()*100 as signed) SECOND), #生成有时间大顺序随机注册时间
        date_add(date_add(create_time,interval +@i*cast(rand()*100 as signed) SECOND), interval + cast(rand()*1000000 as signed) SECOND) #生成有时间大顺序的随机的最后登录时间
from t;
select count(1) from t;
#==================此处结束反复执行=====================
 
 
#创建索引(视情况执行)
create index idx_dept on t(dept);
create index idx_create_time on t(create_time);
create index idx_last_login_time on t(last_login_time);










遇到的问题： 

insert into t(dept, age, name, create_time, last_login_time) 
select left(rand()*10,1) as dept,               #随机生成1~10的整数
       FLOOR(20+RAND() *(50 - 20 + 1)) as age,  #随机生成20~50的整数
        concat('user_',@i:=@i+1),               #按序列生成不同的name
        date_add(create_time,interval +@i*cast(rand()*100 as signed) SECOND), #生成有时间大顺序随机注册时间
        date_add(date_add(create_time,interval +@i*cast(rand()*100 as signed) SECOND), interval + cast(rand()*1000000 as signed) SECOND) #生成有时间大顺序的随机的最后登录时间
from t
> 1206 - The total number of locks exceeds the lock table size
> Time: 538.418s


解决方案：

https://major.io/2010/02/16/mysql-the-total-number-of-locks-exceeds-the-lock-table-size-2/
If you’re running an operation on a large number of rows within a table that uses the InnoDB storage engine, you might see this error:

ERROR 1206 (HY000): The total number of locks exceeds the lock table size

MySQL is trying to tell you that it doesn’t have enough room to store all of the row locks that it would need to execute your query. 
The only way to fix it for sure is to adjust innodb_buffer_pool_size and restart MySQL. By default, this is set to only 8MB, 
which is too small for anyone who is using InnoDB to do anything.

If you need a temporary workaround, reduce the amount of rows you’re manipulating in one query. 
For example, if you need to delete a million rows from a table, try to delete the records in chunks of 50,000 or 100,000 rows. 
If you’re inserting many rows, try to insert portions of the data at a single time.














CREATE TABLE `order_info` (
  `id` bigint(32) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) NOT NULL COMMENT '订单号',
  `order_amount` decimal(8,2) NOT NULL COMMENT '订单金额',
  `merchant_id` bigint(32) NOT NULL COMMENT '商户ID',
  `user_id` bigint(32) NOT NULL COMMENT '用户ID',
  `order_freight` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '运费',
  `order_status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '订单状态,10待付款，20待接单，30已接单，40配送中，50已完成，55部分退款，60全部退款，70取消订单',
  `trans_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '交易时间',
  `pay_status` tinyint(3) NOT NULL DEFAULT '2' COMMENT '支付状态,1待支付,2支付成功,3支付失败',
  `recharge_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '支付完成时间',
  `pay_amount` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '实际支付金额',
  `pay_discount_amount` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '支付优惠金额',
  `address_id` bigint(32) NOT NULL COMMENT '收货地址ID',
  `delivery_type` tinyint(3) NOT NULL DEFAULT '2' COMMENT '配送方式，1自提。2配送',
  `delivery_status` tinyint(3) DEFAULT '0' COMMENT '配送状态，0 配送中，2已送达，3待收货，4已送达',
  `delivery_expect_time` timestamp NULL DEFAULT NULL COMMENT '配送预计送达时间',
  `delivery_complete_time` timestamp NULL DEFAULT NULL COMMENT '配送送达时间',
  `delivery_amount` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '配送运费',
  `coupon_id` bigint(32) DEFAULT NULL COMMENT '优惠券id',
  `cancel_time` timestamp NULL DEFAULT NULL COMMENT '订单取消时间',
  `confirm_time` timestamp NULL DEFAULT NULL COMMENT '订单确认时间',
  `remark` varchar(512) DEFAULT NULL COMMENT '订单备注留言',
  `create_user` bigint(32) DEFAULT NULL COMMENT '创建用户',
  `update_user` bigint(32) DEFAULT NULL COMMENT '更新用户',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '逻辑删除标记',
  PRIMARY KEY (`id`,`order_no`),
  KEY `inx_user_id` (`user_id`),
  KEY `inx_order_no` (`order_no`),
  KEY `inx_merchant_id_update_time` (`merchant_id`,`update_time`),
  KEY `inx_create_time` (`create_time`,`order_no`),
  KEY `inx_trans_time` (`trans_time`)
) ENGINE=InnoDB AUTO_INCREMENT=96311264 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='订单表';





