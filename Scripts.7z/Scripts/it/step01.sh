
# 
ffmpeg -f image2 -i %d.png output.mp4


ffmpeg -r 25 -loop 1 -i 01.png -pix_fmt yuv420p -vcodec libx264 -b:v 600k -r:v 25 -preset medium -crf 30 -s 720x576 -vframes 250 -r 25 -t 10 a.mp4


ffmpeg -r 25 -loop 1 -i 02.png -pix_fmt yuv420p -vcodec libx264 -b:v 600k -r:v 25 -preset medium -crf 30 -s 540x960 -vframes 250 -t 6 b.mp4

# resultfilename=/Users/shawnwang/Downloads/out/Friends.S01E24.1994.BluRay.1080p.x265.10bit.MNHD-FRDS-result001.mkv
# ffmpeg -i $outputfilename \
# -vf "split[fg0][bg0];[bg0]scale=h=1280:w=720,boxblur=10:10[bg1];[fg0]scale=720:(720*ih/iw)[fg1];[bg1][fg1]overlay=0:(H-h)/3,setdar=9/16,drawtext=fontfile=msyh.ttc:text='Part001':x=(w-text_w)/2:y=(h-text_h)/8:fontsize=50:fontcolor=yellow,drawtext=fontfile=msyh.ttc:text='Friends':x=(w-text_w)/2:y=5*(h-text_h)/8:fontsize=50:fontcolor=yellow" \
# -y $resultfilename

ffmpeg -threads 2 -loop 0 -y -r 0.7 -i 02.png -i 001.mp3 -t 10 -absf aac_adtstoasc -vf "scale='if(gt(a*sar,9/16),576,1024*iw*sar/ih)':'if(gt(a*sar,9/16),576*ih/iw/sar,1024)',pad=576:1024:(ow-iw)/2:(oh-ih)/2,setsar=1" -vcodec libx264 -pix_fmt yuv420p -r 30 output.mp4


## tag: Accepted;
ffmpeg -threads 2 -loop 0 -y -r 0.7 -i 003.png -i 001.mp3 -t 10 -absf aac_adtstoasc -vf "scale='if(gt(a*sar,9/16),576,1024*iw*sar/ih)':'if(gt(a*sar,9/16),576*ih/iw/sar,1024)',pad=576:1024:(ow-iw)/2:(oh-ih)/2,setsar=1" -vcodec libx264 -pix_fmt yuv420p -r 30 output.mp4

## 读取一个文件夹内所有的图片，并把所有的图片生成特定的视频；






