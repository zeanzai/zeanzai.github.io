diskutil list
diskutil eraseDisk MS-DOS "WINDOWS10" MBR /dev/disk4

rsync -avh --progress /Volumes/ESD-ISO/ /Volumes/WINDOWS10

rsync -avh --progress --exclude=sources/install.wim /Volumes/ESD-ISO/ /Volumes/WINDOWS10
wimlib-imagex split /Volumes/ESD-ISO/sources/install.wim /Volumes/WINDOWS10/sources/install.swm 4000



