#!/bin/bash
#########################
# Author: ShineDin
# Desc: springboot
#########################

log=iLonghua
app=iLonghua-0.0.1-SNAPSHOT.jar

JAVA_OPTS=""
APP_ARGS=""

if [ ! -d "logs" ];then
    mkdir logs
fi
#########################
status() {
    pid=$(ps -ef | grep " ${app}" | grep -v grep | awk '{print $2}')
    echo -e "${pid}\t\t${app}"
}

stop() {
    pid=$(ps -ef | grep " ${app}" | grep -v grep | awk '{print $2}')
    echo "kill pid: ${pid}"
    if [ -n "${pid}" ];then
        kill -9 ${pid}
    fi
}

start() {
    echo > logs/${log}.log
    nohup java ${JAVA_OPTS} -jar ${app} ${APP_ARGS} > logs/${log}.log 2>&1 &
    tail -f logs/${log}.log
}
#########################
case $1 in
    stop)
        stop
    ;;
    start)
        start
    ;;
    restart)
        stop
        sleep 2s
        start
    ;;
    status)
        status
    ;;
    *)
        echo "{start|stop|restart|status}"
esac

