#!/bin/bash


originFolder=/d/Download/Study02
destinationFolder=/d/Download/Study01/



cd $originFolder

k=0


for i in *.mp4;do 
  name=`echo "$i" | cut -d'.' -f1`
  echo "$name"

  k=$[$k+1]
  num=`echo $k | awk '{printf("%03d",$0)}'`;
  ffmpeg -i "$i" -c:a copy -c:v copy  -y $destinationFolder"$num.mp4" 
  # sleep 10s
done

