#!/bin/bash

#######################################
# 从一个文件夹中读取 png 文件，然后生成一个 6s 中的抖音视频
#######################################

parentFolder=/d/Moonlight/001-culture/
nutStoreFolder=/d/Moonlight/Nutstore/

# 以日期创建 视频输出文件夹
nowdate=`date +%Y-%m-%d`
videosFolder=$nutStoreFolder$nowdate
arcvFolder=$parentFolder$nowdate
mkdir -p $videosFolder $arcvFolder

pngFolder=$parentFolder"pic"
cd $pngFolder

# 获取 背景音乐 文件
bgmFolder=$parentFolder"bgm/"
bgmFile=$bgmFolder"bgm.mp3"
echo $bgmFile


for i in *; do

    pngFile=$pngFolder"/"$i
    echo $pngFile

    name=`echo "$i" | cut -d'.' -f1`
    videoName=$name".mp4"
    videoFile=$videosFolder"/"$videoName
    echo $videoFile

    # 读取 png 图片，并输出视频
    ffmpeg -threads 2 -loop 0 -y -r 0.7 \
    -i $pngFile \
    -i $bgmFile \
    -t 6 -absf aac_adtstoasc \
    -vf "scale='if(gt(a*sar,9/16),576,1024*iw*sar/ih)':'if(gt(a*sar,9/16),576*ih/iw/sar,1024)',pad=576:1024:(ow-iw)/2:(oh-ih)/2,setsar=1" \
    -vcodec libx264 -pix_fmt yuv420p -r 30 $videoFile -hide_banner
    
    sleep 2s

    # 把 png 图片归档
    mv $pngFile $arcvFolder"/"
done

