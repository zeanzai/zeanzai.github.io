#!/bin/bash


originFolder=/d/temp
destinationFolder=/d/temp/cuted



cd $originFolder

k=0


for i in *.mp4;
  do name=`echo "$i" | cut -d'.' -f1`
  echo "$name"

  k=$[$k+1]
  num=`echo $k | awk '{printf("%03d",$0)}'`;
  ffmpeg -i "$i" -c:a copy -c:v copy -map_metadata -1 -y $destinationFolder"$num.mp4" -hide_banner  
  sleep 10s

  # ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 -i "$i"
done



# ffmpeg -i D:\temp\001.mp4 -c:v h264 -q:v 5 -threads 8 D:\temp\002.mp4  

# ffmpeg -i [http://xxx.m3u8](http://xxx.m3u8) -c copy xxx.mp4
# ffmpeg -i "https://cdn1.thedayweplay.lol/106/vod/31/80/z8mzevok_12a3dc61fa084742e8d478478eedff049e2fb2555fb5bf/720/v.m3u8d" -vcodec copy -acodec copy -absf aac_adtstoasc test.mp4
# https://cdn1.thedayweplay.lol/106/vod/31/80/z8mzevok_12a3dc61fa084742e8d478478eedff049e2fb2555fb5bf/720/v.m3u8d

# ffmpeg -i "https://cdn1.thedayweplay.lol/106/vod/31/80/z8mzevok_12a3dc61fa084742e8d478478eedff049e2fb2555fb5bf/720/v.m3u8d" -c copy test.mp4


# ffmpeg -i D:\temp\003.mp4 -map_metadata -1 -y D:\temp\004.mp4 

# ffmpeg -i D:\temp\002.mp4 -hide_banner   
# ffmpeg -i D:\temp\003.mp4 

# ffmpeg -i D:\temp\004.mp4 




ffmpeg -i "$i" -c:a copy -c:v copy -map_metadata -1 -y $destinationFolder"$num.mp4" -hide_banner  


ffmpeg -y -ss 00:00:10 -t 00:56:30 -i /f/Study/MUM-136.mp4 -vcodec copy -acodec copy /f/Study/MUM-136-01.mp4


